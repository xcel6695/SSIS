USE [AdventureWorksDW2012] 
GO
IF OBJECT_ID(N'[dbo].[RefTable]',N'U') IS NOT NULL DROP TABLE  [dbo].[RefTable]
CREATE TABLE [dbo].[RefTable] ([RefColumn] NVARCHAR(400)) 
insert into [dbo].[RefTable] ([RefColumn]) values('April')
insert into [dbo].[RefTable] ([RefColumn]) values('AuguWDst')
insert into [dbo].[RefTable] ([RefColumn]) values('JuUFne')
insert into [dbo].[RefTable] ([RefColumn]) values('NoveJPmber')
insert into [dbo].[RefTable] ([RefColumn]) values('October')
insert into [dbo].[RefTable] ([RefColumn]) values('OQKctober')

